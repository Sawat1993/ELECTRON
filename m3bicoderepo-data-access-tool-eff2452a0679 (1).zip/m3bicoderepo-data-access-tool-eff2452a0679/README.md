## Folder Structure

> package.json - Electron/Node dependencies and commands  
> froge.config.js - Froge configuration  
> src - Source code for UI and Backend logic  
>> lib - Backend Logic  
>> ui - Angular code  
>>> pacakge.json - Angular dependencies and commands  
>>> angular.json - Angular configuration  
>>> src - Angular/UI logic

---

## Commands

1. Go to src/ui and run ``` npm run build ```
2. To run app in development mode, Go into root directory and run ``` npm run start ```
3. To build app, Go into root directory and run ``` npm run make ```

---

## Add backend controller and method

1. Add controller file in src/lib/controller folder
2. Add respective method in created file.
3. In src/lib/contstant file set apis valiable accordingly.
4. To utilize it on UI add respective method in src/ui/src/app/provider/common.service.ts ``` this.api?.ping() ```

---

## Release

1. Update version in main branch
2. Create release branch with same version
3. Make App out of release branch
