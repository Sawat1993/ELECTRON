import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <div>
    <router-outlet></router-outlet>
    </div>
    <p-toast position="top-center"></p-toast>
    `
})
export class AppComponent {
}
