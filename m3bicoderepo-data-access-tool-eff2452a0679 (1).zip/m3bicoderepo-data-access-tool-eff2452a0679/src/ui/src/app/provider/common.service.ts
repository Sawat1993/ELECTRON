import { Injectable } from '@angular/core';
import { from, Subscription } from 'rxjs';
import { COLOR, ERROR, RULE } from '../util/contstant';
import { Preload } from '../util/mock';
import { Rule } from '../util/model';
import { MessageService } from 'primeng/api';

@Injectable({ providedIn: 'root' })
export class CommonService {
    private _rule: Rule;
    private readonly colors = COLOR;
    private w: any;
    private api: any;
    private _DBURL = '';
    private _DBName = '';
    private readonly error = ERROR;
    constructor(private readonly messageService: MessageService) {
        this.w = window;
        this.api = this.w['API'] || Preload;
        this._rule = RULE;
    }

    get DBURL() {
        return this._DBURL;
    }

    set DBURL(val: string) {
        this._DBURL = val;
    }

    get DBName() {
        return this._DBName;
    }

    set DBName(val: string) {
        this._DBName = val;
    }

    get rule(): Rule {
        return this._rule;
    }

    set rule(val: Rule) {
        this._rule = val;
    }

    showSuccess(msg: string) {
        this.messageService.add({ severity: 'success', summary: 'Success', detail: msg });
    }

    showError(msg: string) {
        this.messageService.add({ severity: 'error', summary: 'Error', detail: msg });
    }

    showInfo(msg: string) {
        this.messageService.add({ severity: 'info', summary: 'Error', detail: msg });
    }

    createQuery(val: any, initialQuery: any = { $and: [] }) {
        const query = initialQuery;
        const schema: any = {};
        for (const key of Object.keys(val)) {
            if (val[key]?.length > 0) {
                query.$and.push({ [key]: { $in: val[key] } });
                schema[key] = this.getType(val[key][0]);
            }
        }
        return { query: query.$and.length === 0 ? {} : query, schema };
    }

    private getType(val: any) {
        if (typeof val === 'string' || val instanceof String) {
            return 'String';
        } else {
            return 'Number';
        }
    }

    getColor(index: number) {
        return this.colors[index % (this.colors.length)];
    }

    resetRule() {
        this._rule = RULE;
    }

    ping() {
        return this.getObservable(this.api?.ping());
    }

    connect(val: string) {
        return this.getObservable(this.api?.connect(val))
    }

    disconnect() {
        return this.getObservable(this.api?.disconnect())
    }

    getData(collection: string, schema: any, query: any, skip?: number, limit?: number, sort?: any, project?: any, numberFields?: string[]) {
        return this.getObservable(this.api?.getData(collection, schema, query, skip, limit, sort, project, numberFields))
    }

    getCount(collection: string, schema: any, query: any) {
        return this.getObservable(this.api?.getCount(collection, schema, query))
    }

    getTotal(collection: string, schema: any, query: any, fields: string[]) {
        return this.getObservable(this.api?.getTotal(collection, schema, query, fields))
    }

    getGroup(collection: string, schema: any, query: any, group: string, accu: string) {
        return this.getObservable(this.api?.getGroup(collection, schema, query, group, accu))
    }

    getDistinctValue(collection: string, field: string, query: any = {}, schema: any = {}) {
        return this.getObservable(this.api?.getDistinctValue(collection, field, query, schema))
    }

    getFields(collection: string, keys?: string) {
        return this.getObservable(this.api?.getFields(collection, keys));
    }

    getCollection() {
        return this.getObservable(this.api?.getCollections())
    }


    favoriteConnections(val: any) {
        return this.getObservable(this.api?.favoriteConnections(val));
    }

    recentConnections(val: any) {
        return this.getObservable(this.api?.recentConnections(val))
    }

    getConnections() {
        return this.getObservable(this.api?.getConnections())
    }

    addDashboard(val: any) {
        return this.getObservable(this.api?.addDashboard(val))
    }

    deleteDashboard(val: number) {
        return this.getObservable(this.api?.deleteDashboard(val))
    }

    editDashboard(val: any) {
        return this.getObservable(this.api?.editDashboard(val))
    }

    getDashboard() {
        return this.getObservable(this.api?.getDashboard())
    }

    addCurrency(val: any) {
        return this.getObservable(this.api?.addCurrency(val))
    }

    getCurrency() {
        return this.getObservable(this.api?.getCurrency())
    }

    getObservable(promise: Promise<any>) {
        if (promise) {
            return from(promise);
        }
        // return from(Promise.resolve())
        return from(Promise.reject(this.error))
    }

    unsubscribeSubs(subs: Subscription[]) {
        subs.forEach(s => {
            s.unsubscribe();
        })
    }

}