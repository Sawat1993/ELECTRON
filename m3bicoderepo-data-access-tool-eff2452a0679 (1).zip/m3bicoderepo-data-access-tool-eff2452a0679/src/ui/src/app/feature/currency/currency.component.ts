import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/app/provider/common.service';
import { ExcelService } from 'src/app/provider/excel.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-currency',
  templateUrl: './currency.component.html',
  styleUrls: ['./currency.component.css']
})
export class CurrencyComponent implements OnInit, OnDestroy {
  collections: string[] = [];
  generatingDownload = false;
  currencies: string[] = [];
  fromCurrency = '';
  toCurrency = '';
  collection = '';
  mongoFields: string[] = [];
  headers: string[] = [];
  currencyFields: string[] = [];
  monthField = '';
  yearField = '';
  data: string[][] = [[]];
  field = {
    rate: '',
    from: '',
    to: '',
    month: '',
    year: ''
  }
  subs: Subscription[] = [];
  constructor(private readonly commonService: CommonService, private readonly excelService: ExcelService, private readonly router: Router) { }

  ngOnInit(): void {
    const sub = this.commonService.getCollection().subscribe(d => {
      this.collections = d;
      this.subs.push(this.commonService.getCurrency().subscribe(c => {
        if (c.collection && this.collections.includes(c.collection)) {
          this.collection = c.collection;
          delete c.collection;
          this.fetchMongoFields();
          this.field = c;
          this.fetchCurrency()
        }
      }))
    }, e => {
      console.log(e)
    })
    this.subs.push(sub);
  }

  fetchMongoFields() {
    const sub = this.commonService.getFields(this.collection).subscribe(d => {
      this.mongoFields = d;
    }, e => {
      console.log(e)
    });
    this.subs.push(sub);
  }

  fetchCurrency() {
    const sub = this.commonService.getDistinctValue(this.collection, this.field.from).subscribe(d => {
      this.currencies = ['USD'].concat(d);
    });
    this.subs.push(sub);
  }

  import() {
    document.getElementById('upload-currency')?.click();
  }

  addfile(e: any) {
    this.ngOnDestroy();
    const sub = this.excelService.readFile(e).subscribe(d => {
      this.headers = d.header;
      console.log(this.headers)
      this.data = d.data;
    })
    this.subs.push(sub);
  }


  back() {
    this.router.navigateByUrl('home')
  }

  getUniqueVal(index: number) {
    return this.data.map(d => new Date(d[index])).filter((v, i, a) => a.indexOf(v) === i);
  }

  execute() {
    this.generatingDownload = true
    this.subs.push(this.commonService.addCurrency({ collection: this.collection, ...this.field }).subscribe());

    const data = [[...this.headers]]
    // const dateIndex = this.headers.findIndex(h => h == this.dateField);
    const monthIndex = this.headers.findIndex(h => h == this.monthField);
    const yearIndex = this.headers.findIndex(h => h == this.yearField);
    const currencyIndex: number[] = [];
    this.currencyFields.forEach(f => {
      currencyIndex.push(this.headers.findIndex(h => h == f));
      data[0].push(f + '_' + this.toCurrency);
    })
    const sub = this.commonService.getData(this.collection, { from: 'String' },
      {
        [this.field.from]: { $in: [this.fromCurrency, this.toCurrency] },
        [this.field.month]: { $in: this.getUniqueVal(monthIndex) },
        [this.field.year]: { $in: this.getUniqueVal(yearIndex) }
      }).subscribe(d => {
        this.data.forEach(rcd => {
          const record = [...rcd];
          currencyIndex.forEach((index: number) => {
            let val = NaN;
            const year = record[yearIndex];
            const month = record[monthIndex];
            const fromRate = this.fromCurrency == 'USD' ? { [this.field.rate]: 1 } : d.find((cur: any) => cur[this.field.from] == this.fromCurrency && cur[this.field.year] == year && cur[this.field.month] == month);
            const toRate = this.toCurrency == 'USD' ? { [this.field.rate]: 1 } : d.find((cur: any) => cur[this.field.from] == this.toCurrency && cur[this.field.year] == year && cur[this.field.month] == month)

            if (fromRate && toRate) {
              val = Number(record[index]) * fromRate[this.field.rate] * (1 / toRate[this.field.rate]);
            }
            record.push(val.toString());
          })
          data.push(record);
        })
        this.excelService.exportAsExcelFileAOA(data, 'currency');
        this.generatingDownload = false;
      }, e => {
        console.log(e)
        this.generatingDownload = false;

      })
    this.subs.push(sub);
  }

  ngOnDestroy(): void {
    this.commonService.unsubscribeSubs(this.subs);
  }
}
