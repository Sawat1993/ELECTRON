import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-utility',
  templateUrl: './utility.component.html',
  styleUrls: ['./utility.component.css']
})
export class UtilityComponent {

  constructor(private readonly router: Router) { }

  openCurrency() {
    this.router.navigateByUrl('currency');
  }

}
