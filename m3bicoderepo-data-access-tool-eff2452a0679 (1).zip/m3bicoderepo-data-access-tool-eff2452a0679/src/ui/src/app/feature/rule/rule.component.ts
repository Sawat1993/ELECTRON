import { Component, EventEmitter, Input, OnChanges, OnDestroy, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/app/provider/common.service';
import { CONTENT_TYPE, RULE } from 'src/app/util/contstant';
import { Rule, Type } from 'src/app/util/model';
import {MenuItem} from 'primeng/api';
import { ExcelService } from 'src/app/provider/excel.service';

@Component({
  selector: 'app-rule',
  templateUrl: './rule.component.html',
  styleUrls: ['./rule.component.css']
})
export class RuleComponent implements OnChanges, OnDestroy {
  @Input() rule: Rule = RULE;
  @Output() delete: EventEmitter<number> = new EventEmitter();
  display = false;
  index = 0;
  items: MenuItem[];
  collections: string[] = [];
  types = CONTENT_TYPE;
  mongoFields: string[] = [];
  subs: Subscription[] = [];
  activeIndex = 0;


  constructor(
    private readonly commonService: CommonService,
    private readonly router: Router,
    private readonly  excelService: ExcelService
  ) { 
    this.items = [{
      label: 'Dashboard Deatils',
      command: (event: any) => {
          this.activeIndex = 0;
      }
  },
  {
      label: 'Filter Deatils',
      command: (event: any) => {
          this.activeIndex = 1;
      }
  },
  {
      label: 'Content Deatils',
      command: (event: any) => {
          this.activeIndex = 2;
      }
  }
];
  }

  ngOnChanges(): void {
    this.fetchMongoFields();
    const sub = this.commonService.getCollection().subscribe(d => {
      this.collections = d.sort();
    }, e => {
      console.log(e)
    })
    this.subs.push(sub);
  }

  fetchMongoFields() {
    const sub = this.commonService.getFields(this.rule.collection).subscribe(d => {
      this.mongoFields = d.sort();
      this.fetchMongoObjectFields();
    }, e => {
      console.log(e)
    });
    this.subs.push(sub);
  }

  fetchMongoObjectFields() {
    if(this.rule.isObject && this.rule.objectField) {
      const sub = this.commonService.getFields(this.rule.collection, this.rule.objectField).subscribe(d => {
        this.mongoFields = this.mongoFields.filter(f => f !== this.rule.objectField && !f.includes('.'));
        d.sort().forEach((ele: string) => {
          this.mongoFields.push(`${this.rule.objectField}.${ele}`)
        });;
      }, e => {
        console.log(e)
      });
      this.subs.push(sub);
    }
  }

  addFilter() {
    this.rule.filters.push({
      key: '',
      label: ''
    })
  }

  removeFilter(i: number) {
    this.rule.filters.splice(i, 1);
  }

  addContent(type: Type) {
    this.rule.contents.push({
      type: type,
      width: 'col-12',
      collection: this.rule.collection,
      title: '',
      data: []
    })
  }

  editContent(i: number) {
    this.index = i;
    this.display = true
  }

  removeContent(i: number) {
    this.rule.contents.splice(i, 1);
  }

  

  export() {
    this.excelService.saveAsJSON(this.rule, this.rule.name)
  }
  
  view() {
    this.commonService.rule = this.rule;
    this.router.navigateByUrl('dashboard');
  }

  deleteRule() {
    this.delete.emit(this.rule.timestamp)
  }

  save() {
    const sub = this.commonService.editDashboard(this.rule).subscribe(d => {
      this.commonService.showSuccess('Operation Completed');
      if(this.activeIndex === 0) {
        this.fetchMongoObjectFields();
      }
      this.activeIndex = this.activeIndex === 2 ? 0 : this.activeIndex + 1; 
    }, e => {
      this.commonService.showError('Something went Wrong')
    })
    this.subs.push(sub);
  }

  ngOnDestroy(): void {
    this.commonService.unsubscribeSubs(this.subs);
  }

}
