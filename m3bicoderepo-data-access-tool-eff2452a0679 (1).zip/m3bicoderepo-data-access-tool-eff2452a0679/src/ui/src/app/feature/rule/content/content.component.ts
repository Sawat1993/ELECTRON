import { Component, Input, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/app/provider/common.service';
import { CONTENT } from 'src/app/util/contstant';
import { Content } from 'src/app/util/model';

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnDestroy {
 @Input() content: Content = CONTENT;
 @Input() mongoFields: string[] = [];
 @Input() collections: string[] = [];
 private readonly subs: Subscription[] = [];

 constructor(private readonly commonService: CommonService) {}

 removeData(i: number, data: any) {
  data.splice(i, 1);
}

fetchMongoFields() {
  if(this.content.collection){
    const sub = this.commonService.getFields(this.content.collection).subscribe(d => {
      this.mongoFields = d;
    }, e => {
      console.log(e)
    });
    this.subs.push(sub);
  }
}

ngOnDestroy(): void {
  this.commonService.unsubscribeSubs(this.subs);
}

}
