import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/app/provider/common.service';
import { Router } from '@angular/router';
import { Filter, Rule } from 'src/app/util/model';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, OnDestroy {
  rule: Rule;
  selectedValues: any = {};
  subs: Subscription[] = []
  query: any = {};
  schema: any = {};
  constructor(private readonly commonService: CommonService,
    private readonly router: Router) { 
      this.rule = this.commonService.rule;
    }

  ngOnInit(): void {
    this.rule = this.commonService.rule;
    this.selectedValues = this.rule.query ? JSON.parse(this.rule.query) : {};
    this.updateQuery();
    this.rule.filters.forEach((filter: Filter) => {
      this.selectedValues[filter.key] = [];
      const sub = this.commonService.getDistinctValue(this.rule.collection, filter.key, this.query, this.schema).subscribe(d => {
        filter.data = d;
      }, e => {
        console.log(e);
      })
      this.subs.push(sub);
    });

  }

  updateQuery() {
    const obj = this.commonService.createQuery(this.selectedValues)
    this.query = obj.query;
    this.schema = obj.schema;
  }

  back() {
    this.router.navigateByUrl('home');
  }

  ngOnDestroy(): void {
    this.commonService.unsubscribeSubs(this.subs);
  }

}
