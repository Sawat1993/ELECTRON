import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { SharedModule } from '../shared/shared.module';
import { CardModule } from 'primeng/card';
import { InputTextModule } from 'primeng/inputtext';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { RuleComponent } from './rule/rule.component';
import { AccordionModule } from 'primeng/accordion';
import { DropdownModule } from 'primeng/dropdown';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CheckboxModule } from 'primeng/checkbox';
import { CurrencyComponent } from './currency/currency.component';
import { DialogModule } from 'primeng/dialog';
import { ContentComponent } from './rule/content/content.component';
import { UtilityComponent } from './utility/utility.component';
import { SettingComponent } from './setting/setting.component';
import { StepsModule } from 'primeng/steps';

@NgModule({
  imports: [
    BrowserAnimationsModule,
    CommonModule,
    SharedModule,
    CardModule,
    InputTextModule,
    FormsModule,
    ButtonModule,
    AccordionModule,
    DropdownModule,
    CheckboxModule,
    DialogModule,
    StepsModule
  ],
  declarations: [LoginComponent, HomeComponent, RuleComponent, DashboardComponent, CurrencyComponent, ContentComponent, UtilityComponent, SettingComponent],
  exports: [LoginComponent, HomeComponent, RuleComponent]
})
export class FeatureModule { }
