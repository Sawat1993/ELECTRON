import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/provider/common.service';
import { Subscription } from 'rxjs';
import { Rule } from 'src/app/util/model';
import { RULE } from 'src/app/util/contstant';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy {

  rules: Rule[] = [];
  rule: Rule = RULE;
  subs: Subscription[] =[];
  showRule = false;


  constructor(private readonly router: Router, private readonly commonService: CommonService) {
     }

  ngOnInit() {
    const sub = this.commonService.getDashboard().subscribe(d => {
      this.rules = d;
      if(this.rules.length > 0) this.edit(this.rules[0]);
    }, e => {
      console.log(e)
    });
    this.subs.push(sub);
  }

  edit(rule: any) {
    this.deselectAll();
    rule.selected = true;
    this.rule = rule;
    this.showRule = true;
  }

  viewDashboard(rule: Rule) {
    this.commonService.rule = rule;
    this.router.navigateByUrl('dashboard');
  }

  delete(timestamp: number) {
    const sub = this.commonService.deleteDashboard(timestamp).subscribe(d => {
      this.rules = this.rules.filter((r: any) => r.timestamp !== timestamp);
      this.showRule = false;
      this.commonService.showSuccess('Deleted Successfully');
    }, e => {
      console.log(e)
    })
    this.subs.push(sub)
  }

  add() {
    this.deselectAll();
    this.rule = JSON.parse(JSON.stringify(RULE));
    this.rules.unshift(this.rule);
    this.showRule = true;
  }

  deselectAll() {
    this.rules.forEach((r:any) => {
      r.selected = false;
    });
  }

  import() {
    document.getElementById('upload-button')?.click();
  }

  addFile(evt: any) {
    const target: DataTransfer = <DataTransfer>(evt.target);
    if (target.files.length !== 1) throw new Error('Cannot use multiple files');
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      const text: string = e.target.result;
      const rule: Rule = JSON.parse(text);
      rule.timestamp = Date.now();
      const sub = this.commonService.addDashboard(rule).subscribe(d => {
        this.ngOnInit();
      })
      this.subs.push(sub);
    };
    reader.readAsText(target.files[0]);  }

  ngOnDestroy(): void {
    this.commonService.unsubscribeSubs(this.subs)
  }

}
