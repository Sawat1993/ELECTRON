import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main',
  template: `
    <div class="flex h-screen">
      <div class="h-full w-5rem"><app-header></app-header></div>
      <div class="h-full overflow-auto" style="width: calc(100% - 5rem);"><router-outlet></router-outlet></div>
      <app-footer></app-footer>
    </div>
    `
})
export class MainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
