import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from './feature/login/login.component';
import { HomeComponent } from './feature/home/home.component';
import { MainComponent } from './main.component';

import { AuthGuardService } from './provider/auth-gaurd.service';
import { RuleComponent } from './feature/rule/rule.component';
import { CurrencyComponent } from './feature/currency/currency.component';

import { DashboardComponent } from './feature/dashboard/dashboard.component';
import { UtilityComponent } from './feature/utility/utility.component';
import { SettingComponent } from './feature/setting/setting.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'currency',
    component: CurrencyComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: '',
    component: MainComponent,
    canActivate: [AuthGuardService],
    children: [
      {
        path: 'home',
        component: HomeComponent
      },
      {
        path: 'utility',
        component: UtilityComponent
      },
      {
        path: 'setting',
        component: SettingComponent
      },
      {
        path: 'rule',
        component: RuleComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }