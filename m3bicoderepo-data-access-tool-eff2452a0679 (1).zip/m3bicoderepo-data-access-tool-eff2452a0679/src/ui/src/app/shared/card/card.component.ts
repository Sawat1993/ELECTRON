import { Component, Input, OnChanges, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/app/provider/common.service';
import { Data } from 'src/app/util/model';
@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnChanges, OnDestroy {

  @Input() title = '';
  @Input() distinct = false;
  @Input() keys: Data[] = [];
  @Input() collection = '';
  @Input() contentQuery = '';
  @Input() query: any = {};
  @Input() schema: any = {};
  value = '';
  loading = false;
  subs: Subscription[] = [];

  constructor(private readonly commonService: CommonService) {}

  ngOnChanges(): void {
    this.filterChanged();
  }

  filterChanged() {
    if(this.keys.length === 1 && this.distinct) {
      this.loading = true;
      const sub = this.commonService.getDistinctValue(this.collection, this.keys[0].key, this.query, this.schema).subscribe(d => {
        this.value = d.length;
        this.loading = false;
      }, e => {
        console.log(e)
        this.loading = false;
      })
      this.subs.push(sub);
    } else if(this.keys.length > 0) {
      const obj = this.commonService.createQuery(this.contentQuery ? JSON.parse(this.contentQuery) : {});
      this.loading = true;
      const sub = this.commonService.getTotal(this.collection, {...this.schema, ...obj.schema}, 
        {...this.query, ...obj.query}, this.keys.map(k => k.key)).subscribe(d => {
        this.value = Intl.NumberFormat().format(d);
        this.loading = false;
      }, e => {
        console.log(e)
        this.loading = false;
      })
      this.subs.push(sub);
    }
  }

  ngOnDestroy(): void {
    this.commonService.unsubscribeSubs(this.subs);
  }
}
