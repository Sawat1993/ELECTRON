import { Component, OnInit, OnDestroy } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/app/provider/common.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnDestroy {

  subs: Subscription[] = [];
  name = '';
  url = '/home';

  constructor(private readonly router: Router,
    private readonly commonService: CommonService) { }

  ngOnInit() {
    const sub = this.router.events.subscribe((val) => {
      if (val instanceof NavigationEnd) {
        this.url = val.url;
      }
    });
    this.name = this.commonService.DBName;
    this.subs.push(sub)
  }

  logOut() {
    const sub = this.commonService.disconnect().subscribe();
    this.subs.push(sub);
    this.navigate('login');
  }

  navigate(val: string) {
    this.router.navigateByUrl(val);
  }

  ngOnDestroy(): void {
    this.commonService.unsubscribeSubs(this.subs);
  }

}
