import { Component, Input, OnChanges, OnDestroy } from '@angular/core';
import { LazyLoadEvent } from 'primeng/api';
import { forkJoin, Subscription } from 'rxjs';
import { CommonService } from 'src/app/provider/common.service';
import { ExcelService } from 'src/app/provider/excel.service';
import { Data } from 'src/app/util/model';


@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnChanges, OnDestroy {

  @Input() title = '';
  @Input() column: Data[] = [];
  @Input() collection: string = '';
  @Input() query: any = {};
  @Input() schema: any = {};
  data: any = [];
  loading: boolean = false;
  totalRecords = 0;
  private limit: number = 10;
  private skip: number = 0;
  private sortField: string | undefined;
  private sortOrder: number | undefined;
  private subs: Subscription[] = [];

  constructor(private readonly commonService: CommonService, private readonly excelService: ExcelService) { }

  ngOnChanges(): void {
    this.filterChanged();
    const sub = this.commonService.getCount(this.collection, this.schema, this.query).subscribe(d => {
      this.totalRecords = d;
    }, e => {
      console.log(e)
    })
    this.subs.push(sub);
  }

  filterChanged() {
    this.loading = true;
    const sub = this.commonService.getData(this.collection, this.schema, this.query, this.skip, this.limit,
      this.sortField && this.sortOrder ? { [this.sortField]: this.sortOrder } : undefined, this.getProjection(),
      this.column.filter(c => c.isNumber).map(c => c.key)).subscribe(d => {
        this.data = d;
        this.loading = false;
      }, e => {
        console.log(e)
        this.loading = false;
      })
    this.subs.push(sub);
  }

  loadData(event: LazyLoadEvent) {
    this.limit = event.rows || 0;
    this.skip = event.first || 0;
    this.sortField = event.sortField;
    this.sortOrder = event.sortOrder;
    this.filterChanged();
  }

  export() {
    let data: any[] = [];
    const dbCall: any[] = [];
    if (this.totalRecords <= 500) {
      for (let index = 0; index < this.totalRecords; index = index + 50) {
        dbCall.push(this.commonService.getData(this.collection, this.schema, this.query, index, 50,
          this.sortField && this.sortOrder ? { [this.sortField]: this.sortOrder } : undefined, this.getProjection()))
      }
      const sub = forkJoin(dbCall).subscribe((d: any[]) => {
        data = data.concat(...d);
        this.excelService.exportAsExcelFile(data, this.title);
      }, e => {
        console.log(e)
        this.loading = false;
      })
      this.subs.push(sub);
    }
  }

  getProjection() {
    const project: any = {_id: 0};
    for (const col of this.column) {
        project[col.key] = 1;
    }
    return project;
  }

  getValue(obj: any, key: string) {
    if(key.includes('.')) {
      return obj[key.split('.')[0]][key.split('.')[1]];
    } else {
      return obj[key];
    }
  }

  ngOnDestroy(): void {
    this.commonService.unsubscribeSubs(this.subs);
  }
}
