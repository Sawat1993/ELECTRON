export const Preload = {
    connect: (...args: any) => Promise.resolve(),
    getFields: (...args: any) => Promise.resolve([1,2,3])
}