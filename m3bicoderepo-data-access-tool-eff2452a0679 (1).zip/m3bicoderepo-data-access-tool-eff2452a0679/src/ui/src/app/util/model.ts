export type Rule = {
    name: string,
    desc: string,
    selected?: boolean,
    query?: string,
    timestamp: number,
    collection: string,
    isObject?: boolean,
    objectField?: string,
    filters: Filter[],
    contents: Content[]
}

export type Type = { code: 'card' | 'table' | 'pie' | 'line' | 'bar', label: string }

export type Width = 'col-12' | 'col-6' | 'col-4' | 'col-3'

export type Data = {
    key: string,
    label?: string,
    isNumber?: boolean
}

export type Filter = {
    key: string,
    label: string,
    data?: string[]
}

export type Content = {
    type: Type,
    width: Width,
    title: string,
    query?: string,
    desc?: string,
    data: Data[],
    collection?: string,
    distinct?: boolean,// only for card
    group?: string// only for chart
}