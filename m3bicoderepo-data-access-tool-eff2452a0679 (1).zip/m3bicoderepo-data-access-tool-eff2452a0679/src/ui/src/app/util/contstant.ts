import { Content, Rule, Type } from "./model";


export const RULE: Rule = {
    name: '',
    desc: '',
    timestamp: Date.now(),
    collection: '',
    filters: [{
        key: '',
        label: ''
    }],
    contents: []
}

export const CARD: Type = {
    code: 'card',
    label: 'Card'
};

export const TABLE: Type = {
    code: 'table',
    label: 'Table'
};

export const PIE: Type = {
    code: 'pie',
    label: 'Pie'
};

export const BAR: Type = {
    code: 'bar',
    label: 'Bar'
};

export const LINE: Type = {
    code: 'line',
    label: 'Line'
};

export const CONTENT_TYPE: Type[] = [CARD, TABLE, LINE, BAR, PIE];

export const COLOR = [
    "#42A5F5",
    "#FFA726",
    "#26C6DA",
    "#66BB6A",
    "#7E57C2"
];

export const ERROR = 'API not found';

export const MENU = [{
    label: 'New Connection',
    icon: 'pi-plus',
    options: [],
    highlighted: true
}, {
    label: 'Favorites',
    icon: 'pi-star',
    options: []
}, {
    label: 'Recents',
    icon: 'pi-clock',
    options: []
}];

export const CONTENT: Content = {
    type: {code: 'card', label: 'Card'},
    width: 'col-12',
    title: '',
    data: []
}